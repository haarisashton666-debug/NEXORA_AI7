import os
import sqlite3
import hashlib
import secrets
from datetime import datetime

import streamlit as st
from openai import OpenAI

APP_DIR = os.path.dirname(os.path.abspath(__file__))
DB_PATH = os.path.join(APP_DIR, "nexora.db")

st.set_page_config(
    page_title="NEXORA AI",
    page_icon="✦",
    layout="wide",
    initial_sidebar_state="expanded",
)

# ---------- Database ----------
def db():
    conn = sqlite3.connect(DB_PATH, check_same_thread=False)
    conn.execute("""CREATE TABLE IF NOT EXISTS users (
        username TEXT PRIMARY KEY, salt TEXT NOT NULL, password_hash TEXT NOT NULL,
        created_at TEXT NOT NULL
    )""")
    conn.execute("""CREATE TABLE IF NOT EXISTS chats (
        id INTEGER PRIMARY KEY AUTOINCREMENT, username TEXT NOT NULL,
        title TEXT NOT NULL, messages TEXT NOT NULL, created_at TEXT NOT NULL
    )""")
    conn.commit()
    return conn

def hash_password(password, salt):
    return hashlib.pbkdf2_hmac("sha256", password.encode(), salt.encode(), 180000).hex()

def register_user(username, password):
    conn = db()
    try:
        salt = secrets.token_hex(16)
        conn.execute("INSERT INTO users VALUES (?, ?, ?, ?)",
                     (username, salt, hash_password(password, salt), datetime.utcnow().isoformat()))
        conn.commit()
        return True
    except sqlite3.IntegrityError:
        return False
    finally:
        conn.close()

def verify_user(username, password):
    conn = db()
    row = conn.execute("SELECT salt, password_hash FROM users WHERE username=?", (username,)).fetchone()
    conn.close()
    return bool(row and secrets.compare_digest(hash_password(password, row[0]), row[1]))

def save_chat(username, title, messages):
    import json
    conn = db()
    conn.execute("INSERT INTO chats(username,title,messages,created_at) VALUES(?,?,?,?)",
                 (username, title[:80], json.dumps(messages), datetime.utcnow().isoformat()))
    conn.commit()
    conn.close()

def get_chats(username):
    import json
    conn = db()
    rows = conn.execute("SELECT id,title,messages,created_at FROM chats WHERE username=? ORDER BY id DESC LIMIT 50",
                        (username,)).fetchall()
    conn.close()
    return [{"id": r[0], "title": r[1], "messages": json.loads(r[2]), "created_at": r[3]} for r in rows]

# ---------- AI ----------
def get_api_key():
    try:
        return st.secrets.get("OPENAI_API_KEY", "")
    except Exception:
        return os.getenv("OPENAI_API_KEY", "")

def ai_client():
    key = get_api_key()
    return OpenAI(api_key=key) if key else None

def ask_ai(messages, system_prompt=None, image_bytes=None, image_type="image/png"):
    client = ai_client()
    if client is None:
        raise RuntimeError("Add OPENAI_API_KEY in Streamlit secrets to activate AI features.")
    payload = []
    for m in messages:
        payload.append({"role": m["role"], "content": m["content"]})
    if image_bytes:
        import base64
        b64 = base64.b64encode(image_bytes).decode("utf-8")
        last = payload[-1]["content"]
        payload[-1]["content"] = [
            {"type": "text", "text": last},
            {"type": "image_url", "image_url": {"url": f"data:{image_type};base64,{b64}"}}
        ]
    if system_prompt:
        payload.insert(0, {"role": "system", "content": system_prompt})
    response = client.chat.completions.create(
        model="gpt-4o-mini",
        messages=payload,
        temperature=0.7,
    )
    return response.choices[0].message.content

# ---------- Design ----------
st.markdown("""
<style>
@import url('https://fonts.googleapis.com/css2?family=DM+Sans:wght@400;500;600;700&family=Space+Grotesk:wght@500;600;700&display=swap');
:root { --violet:#9b5cff; --blue:#35c7ff; }
html, body, [class*="css"] { font-family:'DM Sans',sans-serif; }
.stApp {
  background:
    radial-gradient(ellipse at 15% 0%, rgba(105,54,190,.28), transparent 36%),
    radial-gradient(ellipse at 90% 15%, rgba(0,157,255,.16), transparent 32%),
    linear-gradient(145deg,#080914 0%,#0b1020 55%,#090a16 100%);
  color:#f4f2ff;
}
[data-testid="stSidebar"] {
  background:linear-gradient(180deg,#101025 0%,#0b1020 100%);
  border-right:1px solid rgba(164,123,255,.22);
}
h1,h2,h3 { font-family:'Space Grotesk',sans-serif !important; }
.hero {
  padding:28px 30px; border:1px solid rgba(160,120,255,.28);
  border-radius:24px; background:linear-gradient(120deg,rgba(112,62,190,.22),rgba(21,136,190,.12));
  box-shadow:0 12px 50px rgba(0,0,0,.22); margin-bottom:22px;
}
.brand { font-family:'Space Grotesk'; font-size:14px; letter-spacing:4px; color:#bda2ff; font-weight:700; }
.gradient {
 background:linear-gradient(90deg,#c49aff,#5bd6ff);
 -webkit-background-clip:text; background-clip:text; color:transparent;
}
.subtle { color:#a9acc7; }
.tile {
 border:1px solid rgba(161,133,255,.22); border-radius:18px; padding:18px;
 background:linear-gradient(145deg,rgba(31,29,62,.82),rgba(13,26,43,.78));
 min-height:132px;
}
div.stButton > button {
 border:1px solid rgba(160,120,255,.35); border-radius:12px;
 background:linear-gradient(100deg,#7041bd,#176b9b); color:white;
 font-weight:600; min-height:42px;
}
div.stButton > button:hover { border-color:#7bdcff; color:white; }
.stTextInput input,.stTextArea textarea,.stSelectbox div[data-baseweb="select"] {
 background:#11162a !important; color:#f5f3ff !important;
 border-color:rgba(150,130,255,.28) !important; border-radius:11px !important;
}
[data-testid="stChatMessage"] { background:rgba(25,28,51,.72); border:1px solid rgba(148,130,255,.13); border-radius:16px; }
hr { border-color:rgba(150,130,255,.16); }
.smallcaps { letter-spacing:2px; text-transform:uppercase; font-size:11px; color:#8f9abd; }
</style>
""", unsafe_allow_html=True)

# ---------- Authentication ----------
if "user" not in st.session_state:
    st.session_state.user = None
if "messages" not in st.session_state:
    st.session_state.messages = []

def auth_screen():
    st.markdown('<div class="hero"><div class="brand">✦ N E X O R A  A I</div><h1 class="gradient">Your intelligence, amplified.</h1><p class="subtle">One workspace for thinking, creating, learning and building.</p></div>', unsafe_allow_html=True)
    left, right = st.columns([1.15, 1], gap="large")
    with left:
        st.markdown("### Welcome to your next workspace")
        st.markdown("""
        - ✧ Ask questions and explore ideas
        - ✧ Write, code and study with AI
        - ✧ Understand documents and images
        - ✧ Keep a history of your work
        """)
        st.caption("A personal AI workspace with a futuristic interface.")
    with right:
        tab1, tab2 = st.tabs(["Sign in", "Create account"])
        with tab1:
            u = st.text_input("Username", key="login_user")
            p = st.text_input("Password", type="password", key="login_pass")
            if st.button("Sign in", use_container_width=True):
                if verify_user(u.strip(), p):
                    st.session_state.user = u.strip()
                    st.rerun()
                else:
                    st.error("Username or password is incorrect.")
        with tab2:
            nu = st.text_input("Choose a username", key="new_user")
            np = st.text_input("Create a password (8+ characters)", type="password", key="new_pass")
            cp = st.text_input("Confirm password", type="password", key="confirm_pass")
            if st.button("Create account", use_container_width=True):
                if len(nu.strip()) < 3:
                    st.error("Username must contain at least 3 characters.")
                elif len(np) < 8:
                    st.error("Use a password with at least 8 characters.")
                elif np != cp:
                    st.error("Passwords do not match.")
                elif register_user(nu.strip(), np):
                    st.success("Account created. Sign in from the first tab.")
                else:
                    st.error("That username is already taken.")

if not st.session_state.user:
    auth_screen()
    st.stop()

# ---------- Main app ----------
with st.sidebar:
    st.markdown('<div class="brand">✦ NEXORA AI</div>', unsafe_allow_html=True)
    st.markdown(f"**Hello, {st.session_state.user}**")
    st.caption("YOUR PERSONAL AI OPERATING SPACE")
    page = st.radio("WORKSPACE", ["Overview", "AI Chat", "AI Writer", "Code Studio", "Smart Study", "Document AI", "Vision AI", "Research Lab", "My History"], label_visibility="visible")
    st.divider()
    st.markdown("**SYSTEM STATUS**")
    if get_api_key():
        st.success("AI engine configured")
    else:
        st.warning("AI key not configured")
    if st.button("Log out", use_container_width=True):
        st.session_state.user = None
        st.session_state.messages = []
        st.rerun()
    st.caption("NEXORA AI • Personal workspace")

def run_tool(prompt, system, uploaded_image=None, uploaded_type="image/png"):
    with st.spinner("NEXORA is thinking..."):
        return ask_ai([{"role":"user","content":prompt}], system, uploaded_image, uploaded_type)

def show_hero(kicker, title, desc):
    st.markdown(f'<div class="hero"><div class="brand">{kicker}</div><h1 class="gradient">{title}</h1><p class="subtle">{desc}</p></div>', unsafe_allow_html=True)

if page == "Overview":
    show_hero("WELCOME TO YOUR AI WORKSPACE", "Think beyond limits.", "Your tools for ideas, learning, creativity and development — all in one place.")
    c1,c2,c3 = st.columns(3)
    for col, emoji, title, desc in [
        (c1,"✦","AI Conversations","Explore questions and ideas with your assistant."),
        (c2,"⌘","Code Studio","Generate, explain and debug code."),
        (c3,"◈","Creative Workspace","Write, study and understand your files.")
    ]:
        with col:
            st.markdown(f'<div class="tile"><h2>{emoji}</h2><b>{title}</b><p class="subtle">{desc}</p></div>', unsafe_allow_html=True)
    st.write("")
    st.markdown("### Choose your next move")
    a,b,c,d = st.columns(4)
    for col, name, target in [(a,"Chat with AI","AI Chat"),(b,"Write something","AI Writer"),(c,"Build with code","Code Studio"),(d,"Study a topic","Smart Study")]:
        with col:
            if st.button(name, use_container_width=True):
                st.session_state["quick_page"] = target
                st.rerun()
    if "quick_page" in st.session_state:
        st.info("Choose **"+st.session_state.pop("quick_page")+"** in the left navigation.")

elif page == "AI Chat":
    show_hero("NEXORA CONVERSATION ENGINE", "Let's explore.", "Ask anything, brainstorm, plan or solve a problem.")
    if st.button("＋ New conversation"):
        st.session_state.messages = []
    for msg in st.session_state.messages:
        with st.chat_message(msg["role"]):
            st.markdown(msg["content"])
    prompt = st.chat_input("Message NEXORA AI...")
    if prompt:
        st.session_state.messages.append({"role":"user","content":prompt})
        with st.chat_message("user"): st.markdown(prompt)
        try:
            with st.chat_message("assistant"):
                answer = ask_ai(st.session_state.messages, "You are NEXORA AI, a helpful, accurate, friendly all-purpose assistant. Be clear and practical.")
                st.markdown(answer)
            st.session_state.messages.append({"role":"assistant","content":answer})
            if st.button("Save this conversation"):
                save_chat(st.session_state.user, prompt[:60] or "Conversation", st.session_state.messages)
                st.success("Conversation saved.")
        except Exception as e:
            st.error(str(e))

elif page == "AI Writer":
    show_hero("CREATIVE INTELLIGENCE", "Words with purpose.", "Create polished content for work, study and everyday life.")
    kind = st.selectbox("What would you like to create?", ["Email","LinkedIn post","Article","Project description","Resume bullet points","Social media caption","Report","Custom"])
    tone = st.selectbox("Writing style", ["Professional","Friendly","Concise","Creative","Academic"])
    brief = st.text_area("Describe what you want to write", height=150, placeholder="Tell NEXORA the topic, audience and important details...")
    if st.button("Generate writing", use_container_width=True):
        if brief.strip():
            try:
                result = run_tool(f"Create a {kind.lower()} in a {tone.lower()} style. Requirements:\n{brief}", "You are an expert writing assistant. Produce useful, original, well-structured writing. Do not invent personal facts.")
                st.markdown("### Your draft")
                st.markdown(result)
                st.download_button("Download draft", result, file_name="nexora_draft.md")
            except Exception as e: st.error(str(e))
        else: st.warning("Enter a topic or brief first.")

elif page == "Code Studio":
    show_hero("DEVELOPER INTELLIGENCE", "Build. Debug. Understand.", "Your AI coding partner for explanations, code generation and debugging.")
    task = st.selectbox("Choose a coding task", ["Generate code","Explain code","Debug an error","Improve or refactor code","Create a project plan"])
    language = st.selectbox("Language / technology", ["Python","JavaScript","HTML + CSS","Bash","C","C++","Java","SQL","Other"])
    details = st.text_area("Describe the task or paste your code/error", height=190)
    if st.button("Run Code Assistant", use_container_width=True):
        if details.strip():
            try:
                result = run_tool(f"Task: {task}\nTechnology: {language}\n\n{details}", "You are NEXORA Code Studio, a careful senior software engineer. Explain assumptions, provide correct code, and mention how to run or test it. Never claim code was executed.")
                st.markdown("### Result")
                st.markdown(result)
                st.download_button("Download result", result, file_name="nexora_code_result.md")
            except Exception as e: st.error(str(e))
        else: st.warning("Describe the task first.")

elif page == "Smart Study":
    show_hero("LEARNING INTELLIGENCE", "Make learning click.", "Understand difficult topics through simple explanations, examples and practice.")
    topic = st.text_input("What are you learning?", placeholder="e.g. Kubernetes, vector calculus, networking...")
    level = st.selectbox("Your level", ["Beginner","Intermediate","Advanced"])
    mode = st.selectbox("Learning mode", ["Explain simply","Step-by-step lesson","Create revision notes","Make a quiz","Give worked examples"])
    if st.button("Start learning", use_container_width=True):
        if topic.strip():
            try:
                result = run_tool(f"Topic: {topic}\nLevel: {level}\nMode: {mode}. Teach clearly, define terms, and use examples appropriate to the level.", "You are a patient expert tutor. Be accurate, structured and encouraging. For quizzes, put answers after the questions.")
                st.markdown("### Your learning session")
                st.markdown(result)
                st.download_button("Download lesson", result, file_name="nexora_lesson.md")
            except Exception as e: st.error(str(e))
        else: st.warning("Enter a topic first.")

elif page == "Document AI":
    show_hero("DOCUMENT INTELLIGENCE", "Ask your documents.", "Upload a PDF or text document and ask NEXORA to explain, summarize or extract information.")
    file = st.file_uploader("Upload a PDF or TXT file", type=["pdf","txt"])
    question = st.text_area("What should NEXORA do with it?", placeholder="Summarize the document, list key points, explain section 2...")
    if st.button("Analyse document", use_container_width=True):
        if not file: st.warning("Upload a document first.")
        elif not question.strip(): st.warning("Enter a question or instruction.")
        else:
            try:
                if file.type == "application/pdf":
                    from pypdf import PdfReader
                    import io
                    reader = PdfReader(io.BytesIO(file.getvalue()))
                    text_content = "\n".join(p.extract_text() or "" for p in reader.pages)
                else:
                    text_content = file.getvalue().decode("utf-8", errors="replace")
                if not text_content.strip(): raise ValueError("No readable text found in this file. Scanned PDFs need OCR.")
                if len(text_content) > 45000: text_content = text_content[:45000] + "\n[Document truncated for this request]"
                result = run_tool(f"DOCUMENT CONTENT:\n{text_content}\n\nUSER REQUEST:\n{question}", "You are a document analysis assistant. Base your answer on the supplied document. Clearly say when information is not present.")
                st.markdown("### Document analysis")
                st.markdown(result)
                st.download_button("Download analysis", result, file_name="nexora_document_analysis.md")
            except Exception as e: st.error(str(e))

elif page == "Vision AI":
    show_hero("VISUAL INTELLIGENCE", "See it differently.", "Upload an image and ask questions about what is visible.")
    img = st.file_uploader("Upload an image", type=["png","jpg","jpeg","webp"])
    question = st.text_area("Ask about the image", value="Describe this image and identify its important details.")
    if img:
        st.image(img, caption="Your uploaded image", use_container_width=True)
    if st.button("Analyse image", use_container_width=True):
        if not img: st.warning("Upload an image first.")
        else:
            try:
                result = run_tool(question, "You are NEXORA Vision, an image understanding assistant. Describe only what can reasonably be observed; distinguish uncertainty.", img.getvalue(), img.type or "image/png")
                st.markdown("### Vision results")
                st.markdown(result)
            except Exception as e: st.error(str(e))

elif page == "Research Lab":
    show_hero("KNOWLEDGE EXPLORER", "Go deeper.", "Turn a complex question into a structured, evidence-conscious explanation.")
    question = st.text_area("Research question", height=130, placeholder="What do you want to understand?")
    depth = st.selectbox("Depth", ["Quick overview","Detailed analysis","Compare alternatives","Pros, cons and recommendations"])
    if st.button("Explore topic", use_container_width=True):
        if question.strip():
            try:
                result = run_tool(f"Research task: {depth}\nQuestion: {question}\n\nProvide a structured answer, explain uncertainty, and suggest reliable sources the user can verify. Do not fabricate citations or claim live web research.", "You are a careful research assistant. Distinguish established facts from interpretation. You do not have live web browsing in this app.")
                st.markdown("### Research brief")
                st.markdown(result)
                st.download_button("Download research brief", result, file_name="nexora_research.md")
            except Exception as e: st.error(str(e))
        else: st.warning("Enter a research question.")

elif page == "My History":
    show_hero("YOUR PERSONAL ARCHIVE", "Ideas worth keeping.", "Conversations saved to this app's database.")
    records = get_chats(st.session_state.user)
    if not records:
        st.info("No saved conversations yet. Open AI Chat and save a conversation.")
    for item in records:
        with st.expander(f"{item['title']}  ·  {item['created_at'][:16]}"):
            for m in item["messages"]:
                st.markdown(("**You:** " if m["role"]=="user" else "**NEXORA:** ") + m["content"])

st.divider()
st.markdown('<p class="smallcaps" style="text-align:center">✦ NEXORA AI · THINK BEYOND LIMITS · BUILT FOR WHAT\'S NEXT</p>', unsafe_allow_html=True)
