# NEXORA AI

A futuristic all-in-one AI workspace built with Streamlit and Python.

## Features
- Account registration and sign-in (local SQLite starter database)
- AI chat
- AI writing assistant
- Code generation, explanation and debugging
- Study tutor and quiz creator
- PDF/TXT document analysis
- Image understanding
- Research-style briefs (AI-generated; no live web browsing)
- Save and revisit chat history

## Run locally
1. Install Python 3.10 or newer.
2. Open a terminal in this folder.
3. Create and activate a virtual environment (optional but recommended):
   - Windows: `py -m venv .venv` then `.venv\\Scripts\\activate`
   - macOS/Linux: `python3 -m venv .venv` then `source .venv/bin/activate`
4. Install packages: `pip install -r requirements.txt`
5. Create `.streamlit/secrets.toml` and add:
   `OPENAI_API_KEY = "your-api-key-here"`
6. Start: `streamlit run app.py`

You can alternatively set the `OPENAI_API_KEY` environment variable.

## Deploy on Streamlit Community Cloud
1. Create a GitHub repository and upload the files in this folder.
2. Open https://share.streamlit.io/ and sign in with GitHub.
3. Choose **Create app**, select your repository, branch and `app.py`.
4. In the app settings, open **Secrets** and add:
   `OPENAI_API_KEY = "your-api-key-here"`
5. Deploy. Streamlit will generate your public app URL.

## Important deployment notes
- Never commit your API key or `.streamlit/secrets.toml` to GitHub.
- This starter uses SQLite for simplicity. Streamlit Community Cloud's local filesystem is not a durable production database; app restarts/redeployments may lose local database data. For production or persistent multi-user accounts, migrate the database/authentication to Supabase or another managed database/auth provider.
- This is a functional starter, not a security-audited production identity system. Do not use it to store sensitive personal information.
- Research Lab does not browse the live internet; it creates structured research-style answers using the configured AI model.
- Document AI extracts selectable PDF text; scanned PDFs require OCR.
